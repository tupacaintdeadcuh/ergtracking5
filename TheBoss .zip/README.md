# ERGTracking5 — Full App

Deploy on Vercel:
- Import this repo
- Root Directory: (leave blank)
- Install Command: `npm install`
- Build Command: (leave blank)
- Output Directory: `public`
- Start Command: `npm start`
- Add env vars from `.env.example` in Vercel → Settings → Environment Variables
- Add Discord OAuth Redirect: `https://YOUR-URL/auth/callback`
